<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, $roles)
    {
        // jeśli użytkownik nie jest zalogowany - przekieruj do logowania
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        // dozwolone role przekazane w trasie, np. "kierownik|administrator"
        $allowed = explode('|', $roles);

        // jeśli ro